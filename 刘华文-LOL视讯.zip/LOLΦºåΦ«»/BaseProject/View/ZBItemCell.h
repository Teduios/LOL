//
//  ZBItemCell.h
//  BaseProject
//
//  Created by apple-jd26 on 15/11/24.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"

@interface ZBItemCell : UICollectionViewCell
@property(nonatomic,strong) TRImageView *iconView;
@property(nonatomic,strong) UILabel *nameLb;
@end


//@interface ZBItemCell : UICollectionViewCell
//
//
//@end