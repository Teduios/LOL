//
//  LatesViewController.h
//  BaseProject
//
//  Created by apple-jd26 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LatestViewModel.h"

@interface LatesViewController : UIViewController
//传入需要的变量确定来显示的是哪一页
@property (nonatomic,assign)ZiXunListType type;
@end
