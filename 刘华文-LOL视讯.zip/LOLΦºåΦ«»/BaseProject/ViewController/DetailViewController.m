//
//  DetailViewController.m
//  BaseProject
//
//  Created by apple-jd26 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DetailViewController.h"
#import "Factory.h"

@interface DetailViewController ()<UIWebViewDelegate>
@property (nonatomic, strong)NSNumber *ID;
@property (nonatomic, strong)UIWebView *webView;
@end

@implementation DetailViewController

- (id)initWithID:(NSNumber *)ID{
    if (self = [super init]) {
        self.ID = ID;
    }
    return self;
}

- (UIWebView *)webView{
    if (!_webView) {
        _webView = [UIWebView new];
        NSString *path=[NSString stringWithFormat:@"http://lol.zhangyoubao.com/mobiles/item/%@?v_=400606&token=9106edd4bac1f8ab738adc3a17630480839b&user_id=13360447&size=middle&t=1446430870", _ID];
        NSURL *url=[NSURL URLWithString:path];
        NSURLRequest *request=[NSURLRequest requestWithURL:url];
        [_webView loadRequest:request];
        _webView.delegate = self;
    }
    return _webView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    UIWebView *webView=[UIWebView new];
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    [Factory addBackItemToVC:self];
//    NSString *path=[NSString stringWithFormat:@"http://lol.zhangyoubao.com/mobiles/item/%@?v_=400606&token=9106edd4bac1f8ab738adc3a17630480839b&user_id=13360447&size=middle&t=1446430870", _ID];
//    NSURL *url=[NSURL URLWithString:path];
//    NSURLRequest *request=[NSURLRequest requestWithURL:url];
//    [webView loadRequest:request];

}
#pragma mark - UIWebViewDelegate
- (void)webViewDidStartLoad:(UIWebView *)webView{
/** 旋转提示 */
    [self showProgress];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [self hideProgress];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hideProgress];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
